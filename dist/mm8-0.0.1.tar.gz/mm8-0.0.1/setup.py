from setuptools import setup

setup(
    name='mm8',
    version='0.0.1',
    packages=['mm8'],
    install_requires=[
        'requests',
        'importlib; python_version == "2.6"',
    ],
)
